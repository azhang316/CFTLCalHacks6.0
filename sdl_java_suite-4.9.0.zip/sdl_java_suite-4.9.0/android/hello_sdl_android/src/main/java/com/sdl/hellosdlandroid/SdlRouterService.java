package com.sdl.hellosdlandroid;


public class SdlRouterService extends  com.smartdevicelink.transport.SdlRouterService {



}
