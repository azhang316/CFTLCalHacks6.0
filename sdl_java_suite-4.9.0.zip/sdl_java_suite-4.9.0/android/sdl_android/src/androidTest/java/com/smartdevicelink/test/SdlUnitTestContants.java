package com.smartdevicelink.test;

public class SdlUnitTestContants {
	public static final String TEST_APP_ID = "123456";

}
