package com.smartdevicelink.test;

/**
 * This class is to help with ambiguous method signatures.
 * @author Joey Grover
 *
 */
public class NullValues {

	public static final String STRING = null;
	public static final Integer INTEGER = null;
	public static final Boolean BOOLEAN = null;
	public static final Double DOUBLE = null;
	
}
