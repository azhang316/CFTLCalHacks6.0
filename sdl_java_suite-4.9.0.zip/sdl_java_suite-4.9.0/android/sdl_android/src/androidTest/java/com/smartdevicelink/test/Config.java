package com.smartdevicelink.test;


public class Config{

    private Config(){}
    
    public static final int SDL_VERSION_UNDER_TEST = 3;
    public static final boolean DEBUG = true;
}
